
#include "base.h"
#include "main.h"

// string
char *newData(int size){
    char *d = malloc(size);
    if (d == NULL) return NULL;
    memset(d,0,size);
    return d;
}


char *newString(char* s){
    char *d = malloc(strlen(s) +1);
    if (d == NULL) return NULL;
    strcpy(d,s);
    return d;
}

char* newMultiString(const char *msg, ...) {
    char buf[2*4096];
    va_list argp;
    va_start(argp, msg);
    vsnprintf(buf, 2*4096, msg, argp);
    va_end(argp); 

    char *data = newString(buf);
    return data;
}

void freeData(char *p){
    if(p != NULL){
        free(p);
        p = NULL;
    }
}

char* getCurrentTime(){
    time_t time_raw_format;
    time(&time_raw_format);
    struct tm *curtime = localtime(&time_raw_format);
    
    if (systemTime) {
        sprintf(systemTime,"%d-%02d-%02d:%02d:%02d:%02d",curtime->tm_year+1900,curtime->tm_mon+1,curtime->tm_mday,\
                                            curtime->tm_hour,curtime->tm_min,curtime->tm_sec);
    } else {
        ERROR("%s\n",strerror(errno));
        systemTime = NULL;
    }
    return systemTime;
}