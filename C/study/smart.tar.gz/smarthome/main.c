/* 
 * File:   main.c
 * Author: topseten
 *
 * Created on December 28, 2014, 11:17 PM
 */

#include "main.h"

/*
 * 
 */
int main(int argc, char** argv) {
    
    // test
//    char *data = newMultiString("%s%s%s%d","hello","data","what?",2);
//    printf("data:%s\n",data);
//    freeData(data);
//    return 0; 
    // end
    //////////////////////////////////////////////////////////////////////////////
    // init var
    int ret = 0;
    int i;
    
    // system init
    ret = InitSystem();
    if(ret < 0){
        return -1;
    }
    
    // test log system
    INFO("%s%s","This is an error of log file.","do you have a list for this?\n");
    
    // setup server socket
//    int SmartPort = 8087;
//    int fd = lib_create_server_socket("*",SmartPort);
//    if (fd < 0) {
//        return -1;
//    }
    
    while(1){
        sleep(1);
    }
    
    DestorySystem();
    return (EXIT_SUCCESS);
}

