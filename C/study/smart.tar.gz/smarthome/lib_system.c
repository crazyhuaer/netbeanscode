

#include "lib_system.h"


// Init the system,such as log signal
int InitSystem(){
    InitSystemPrint();
    InitConfigSystem();
    InitSystemVar();
    InitLogSystem();
    SetupSignal();
}

void InitSystemPrint(){
    printf("----------Smart Home Network Programming--------\n");
}

void InitConfigSystem(){
    printf("\tL__________System params:\n");
    printf("\tL__________Web IP:192.168.2.130\n");
    //printf("\tL__________\n");
}

void InitSystemVar(){
    systemTime = newData(20);
    systemTime = getCurrentTime();
    //log_path = newMultiString("%s%s",systemTime,".log");
    // log_path from config file
    log_path = newString("./smarthome.log");
}

// open the log file
int InitLogSystem(){  
    if (DEBUG_LOG_ENABLED || ERROR_LOG_ENABLED) {
        OpenLogFile(log_path);
    }
}

void sig_handler(int signo) {
    if (signo == SIGINT){
        INFO("%s","received SIGINT\n");
        ERROR("%s","received SIGINT\n");
        DestorySystem();
    }else if (signo == SIGPIPE) {
        struct sigaction sa;

        sa.sa_handler = SIG_IGN;
        sa.sa_flags = 0;

        if (sigemptyset(&sa.sa_mask) == -1 ||
                sigaction(SIGPIPE, &sa, 0) == -1) {
            ERROR("%s","SIGPIPE Error\n");
            DestorySystem();
        }
    }else if(signo == SIGTSTP){
        printf("Ctrl+z,ignore\n");
    }else if(signo == SIGTERM){
        printf("SIGTERM,ignore\n");
    }else{
        ERROR("%s","what?signal?\n");
    }
}

// process the system signals
void SetupSignal() {
    /*
    signal(SIGPIPE, SIG_IGN);
    struct sigaction sa;

    sa.sa_handler = SIG_IGN;
    sa.sa_flags = 0;

    if (sigemptyset(&sa.sa_mask) == -1 ||
            sigaction(SIGPIPE, &sa, 0) == -1) {
        exit(-1);
    }
     * */
    if (signal(SIGINT, sig_handler) == SIG_ERR)
        printf("\ncan't catch SIGINT\n");
    if (signal(SIGPIPE, sig_handler) == SIG_ERR)
        printf("\ncan't catch SIGPIPE\n");
    if (signal(SIGTERM, sig_handler) == SIG_ERR)
        printf("\ncan't catch SIGTERM\n");
    if (signal(SIGTSTP, sig_handler) == SIG_ERR)
        printf("\ncan't catch SIGPIPE\n");
}

void DestorySystem(){
    if (log_path) {
        freeData(log_path);
        log_path = NULL;
    }
    
    if (systemTime){
        freeData(systemTime);
    }
    
    CloseLogFile();
    exit(0);
}